function myExternalFunction() {
  document.getElementById("externalDemo").innerHTML = "Paragraph changed.";
}